import {Tipoincidente} from './tipoincidente';

export class Incidente {
  cezjId:number;
  cezjDescripcion: string ;
  cezjFecha: Date;
  cezjLugar: String ;
  cezjTipoIncidente: Tipoincidente ;
}
