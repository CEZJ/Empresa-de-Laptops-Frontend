export class Tipoincidente {
  cezjId: number;
  cezjNombre: string;
}
