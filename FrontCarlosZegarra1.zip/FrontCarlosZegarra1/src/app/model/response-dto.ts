export class ResponseDto {
  jwt: string;
  roles: string[];
}
