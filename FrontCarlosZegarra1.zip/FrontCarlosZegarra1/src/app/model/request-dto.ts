export class RequestDto {
  username: string;
  password: string;
}
